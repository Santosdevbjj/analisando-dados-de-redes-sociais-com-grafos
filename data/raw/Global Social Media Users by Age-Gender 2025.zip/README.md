# 🌍 Social Media Usage by Age and Gender (2025)

This dataset presents a comprehensive view of global social media usage across various platforms, broken down by gender and age group. It can be used for research, data visualization, marketing analytics, or user behavior analysis.

## 📊 Dataset Overview

| Column | Description |
|:------------------------|:----------------------------------------------------|
| Platform | Name of the social media platform |
| Total Monthly Active Users (Billion) | Approximate global monthly active users of the platform (as of early-mid 2025) |
| Age Group | Specific age range for the demographic breakdown (e.g., 18-24, 25-34) |
| % Female Users (within age group) | Estimated percentage of female users within that specific age group on the platform |
| % Male Users (within age group) | Estimated percentage of male users within that specific age group on the platform |
| Overall % Female Users | Estimated overall percentage of female users on the platform |
| Overall % Male Users | Estimated overall percentage of male users on the platform |
| Key Trends / Notes | Additional insights or specific regional context for the data |

## 📌 Platforms Included

This dataset includes detailed demographic breakdowns for the following major social media platforms:

* Facebook
* Instagram
* Twitter (X)
* Snapchat
* YouTube
* TikTok (Douyin)
* Reddit
* LinkedIn
* Telegram
* WhatsApp
* Discord
* Pinterest
* Tumblr
* Messenger (Facebook Messenger)
* Sina Weibo
* WeChat (Weixin)
* QQ
* LINE
* Threads
* Twitch
* Viber
* Qzone
* Quora
* Kuaishou

## 📁 Files

-   `social_media_demographics.csv`: Clean and structured data containing social media usage statistics by platform, age, and gender.
-   `README.md`: Dataset overview and metadata (this file).

## 📅 Last Updated

July 2025

## 🔍 Potential Use Cases

-   **User behavior analysis:** Understand how different demographic groups interact with various social media platforms.
-   **Market segmentation:** Identify target audiences for advertising campaigns and product development.
-   **Social media marketing trends:** Observe shifts in platform popularity and user demographics over time.
-   **Age and gender-based user predictions:** Formulate hypotheses about future usage patterns.
-   **Demographic visualization and EDA:** Create compelling charts and graphs to illustrate key insights from the data.

## 🔗 Source Assumptions

Data is estimated based on multiple public data sources such as Statista, DataReportal, Pew Research, and various industry reports. These figures are approximations and are subject to change. Specific regional nuances are noted where applicable within the dataset.

---

---
**Author**: [Kawsar Mahmud](https://www.kaggle.com/mdkawsarmahmudsojib)
**Assisted by**: Gemini AI & Chatgpt
**License**: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)
---